﻿using System;
class Program
{
    static void Main(string[] args)
    {
        bool durum=true;
        while (durum)
        {
            Console.WriteLine("HOŞGELDİNİZ");
            Console.WriteLine("Bu bir hesap makinesidir");
            Console.WriteLine("cıkmak için q basın");
            Console.WriteLine("+ toplama işlemi");
            Console.WriteLine("- cıkarma işlemi");
            Console.WriteLine("* çarpma işlemi");
            Console.WriteLine("/ bölme işlemi");
            Console.Write("1.sayıyı giriniz:");
            int sayi1 = Convert.ToInt32(Console.ReadLine());
        
            Console.Write("işlem tipini giriniz (+,-,*,/):");
            string secim = Console.ReadLine()!;

            Console.Write("2.sayıyıyı giriniz:");
            int sayi2 = Convert.ToInt32(Console.ReadLine());
            switch (secim)
         {
            case "+":
             Console.WriteLine("sonuç:"+ (sayi1+sayi2));
             break;
            case "-":
             Console.WriteLine("sonuç:" + (sayi1-sayi2));
             break;
            case "*":
             Console.WriteLine("sonuç:"+ (sayi1*sayi2));
             break;
            case "/":
             if (sayi2!=0)
             {
                Console.WriteLine("sonuç:"+ (sayi1/sayi2));
             }
             else
             {
                Console.WriteLine("Bu sayı bölünemez");
             }
             break;
            default:
                Console.WriteLine("Hatalı işlem girdiniz:");
                break;
         }
            
            Console.WriteLine("---------------");
            Console.WriteLine("Devam etmek istermisinizi (E,H):");
            string seccim = Console.ReadLine()?.ToUpper() ?? "H";
            



            if (seccim !="E")
            {
                durum=false;
                Console.WriteLine("Güle güle cıkmak için bir tuşa bas:");
                Console.ReadKey();
            }
            
        } 
        
        
    }
       
        
}
